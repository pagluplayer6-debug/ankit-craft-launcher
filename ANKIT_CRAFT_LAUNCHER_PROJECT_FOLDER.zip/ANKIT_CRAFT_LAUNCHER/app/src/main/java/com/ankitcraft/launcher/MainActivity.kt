package com.ankitcraft.launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Typeface
import android.content.pm.PackageManager

class MainActivity : Activity() {
    private val minecraftPackage = "com.mojang.minecraftpe"
    private val pickPackRequest = 4102

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 20, 14)
        window.navigationBarColor = Color.rgb(10, 20, 14)
        window.decorView.systemUiVisibility = 0

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(20))
            setBackgroundColor(Color.rgb(10, 20, 14))
        }

        val title = TextView(this).apply {
            text = "ANKIT CRAFT"
            textSize = 29f
            setTextColor(Color.rgb(142, 239, 116))
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "LAUNCHER  •  BEDROCK EDITION"
            textSize = 12f
            letterSpacing = 0.16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(25))
        }
        page.addView(subtitle, matchWrap())

        val status = TextView(this).apply {
            text = minecraftStatus()
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(25, 42, 29))
        }
        page.addView(status, matchWrap())

        page.addView(makeButton("▶  PLAY MINECRAFT") {
            launchMinecraft()
            status.text = minecraftStatus()
        })
        page.addView(makeButton("＋  IMPORT RESOURCE PACK") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/zip", "application/octet-stream"
                ))
            }
            startActivityForResult(intent, pickPackRequest)
        })
        page.addView(makeButton("⚙  DEVICE & PERFORMANCE INFO") {
            val mem = android.app.ActivityManager.MemoryInfo()
            (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mem)
            val totalRam = mem.totalMem / (1024L * 1024L)
            val freeRam = mem.availMem / (1024L * 1024L)
            val info = "Android ${Build.VERSION.RELEASE}  •  API ${Build.VERSION.SDK_INT}\n" +
                "RAM: ${totalRam} MB total, ${freeRam} MB available\n\n" +
                "FPS is controlled by Minecraft and the device. This launcher cannot safely force an FPS value."
            android.app.AlertDialog.Builder(this)
                .setTitle("DEVICE INFO")
                .setMessage(info)
                .setPositiveButton("OK", null)
                .show()
        })

        val note = TextView(this).apply {
            text = "PACK TIP\nChoose a compatible .mcpack file. Android will pass it to Minecraft if the installed version supports the import. Java shaders are not Bedrock packs."
            textSize = 12f
            setTextColor(Color.rgb(190, 202, 190))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(20, 31, 23))
        }
        val noteParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(18) }
        page.addView(note, noteParams)

        val footer = TextView(this).apply {
            text = "Made for Minecraft Bedrock • v1.0"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, 0)
        }
        page.addView(footer, matchWrap())
        setContentView(page)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.rgb(8, 20, 11))
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(142, 239, 116)))
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)
            ).apply { topMargin = dp(12) }
            layoutParams = params
            setOnClickListener { action() }
        }
    }

    private fun isMinecraftInstalled(): Boolean {
        return try {
            packageManager.getPackageInfo(minecraftPackage, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun minecraftStatus(): String =
        if (isMinecraftInstalled()) "●  MINECRAFT BEDROCK DETECTED"
        else "●  MINECRAFT NOT FOUND — install the official game first"

    private fun launchMinecraft() {
        val launch = packageManager.getLaunchIntentForPackage(minecraftPackage)
        if (launch == null) {
            Toast.makeText(this, "Official Minecraft Bedrock was not found.", Toast.LENGTH_LONG).show()
            return
        }
        try { startActivity(launch) }
        catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Could not open Minecraft.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated by Android, kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickPackRequest && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/octet-stream")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startActivity(viewIntent)
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "No app accepted this pack. Try opening the .mcpack from Files.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
