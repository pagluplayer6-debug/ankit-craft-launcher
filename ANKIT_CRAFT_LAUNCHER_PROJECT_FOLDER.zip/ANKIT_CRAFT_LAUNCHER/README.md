# ANKIT CRAFT LAUNCHER (Bedrock) — Android project

This is a starter Android Studio project for a custom Minecraft Bedrock launcher UI.

## Included
- Custom dark green launcher screen
- Detects the official Android Minecraft package (`com.mojang.minecraftpe`)
- Launches the installed Minecraft app (does not bundle or replace Minecraft)
- Lets the user select a resource-pack file and hands it to Android/Minecraft for import
- Shows basic Android/RAM information

## Important limitations
- Minecraft Bedrock must already be installed from a legitimate source.
- The launcher does not modify Minecraft's private data or bypass licensing.
- Resource-pack import depends on Android/Minecraft version and pack compatibility.
- FPS cannot be forced by an external launcher. The performance panel reports device information only.
- Java Edition is not included; Java shaders/mod loaders are separate from Bedrock `.mcpack` packs.

## Build APK
1. Install Android Studio and a compatible JDK (JDK 17).
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

This project has not been compiled or device-tested in this environment. Build and test it on an Android Studio setup before installing.
